
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Trash } from "lucide-react";

interface MedicationFormProps {
  currentMedications: any[];
  medicalHistory: string[];
  onMedicationChange: (medications: any[]) => void;
  onMedicalHistoryChange: (conditions: string[]) => void;
  onAnalyze: () => void;
  isLoading: boolean;
}

// List of common opioid medications
const opioidMedications = [
  { name: "Morphine", potency: "high" },
  { name: "Oxycodone", potency: "high" },
  { name: "Hydrocodone", potency: "moderate" },
  { name: "Fentanyl", potency: "very high" },
  { name: "Codeine", potency: "low" },
  { name: "Tramadol", potency: "low" },
  { name: "Methadone", potency: "high" },
  { name: "Hydromorphone", potency: "high" },
  { name: "Buprenorphine", potency: "moderate" },
  { name: "Oxymorphone", potency: "high" },
  { name: "Tapentadol", potency: "moderate" }
];

export const MedicationForm = ({
  currentMedications,
  medicalHistory,
  onMedicationChange,
  onMedicalHistoryChange,
  onAnalyze,
  isLoading
}: MedicationFormProps) => {
  const [newMed, setNewMed] = useState({
    name: "",
    dosage: "",
    frequency: "",
    duration: ""
  });
  const [newCondition, setNewCondition] = useState("");

  const commonConditions = [
    "Chronic Pain", 
    "Acute Pain", 
    "Post-Surgery Pain", 
    "Cancer Pain", 
    "Neuropathic Pain",
    "Back Pain",
    "Depression",
    "Anxiety",
    "Substance Use Disorder",
    "Respiratory Issues"
  ];

  const handleAddMedication = () => {
    if (!newMed.name || !newMed.dosage || !newMed.frequency) {
      return;
    }

    // Find the selected medication from the opioid list to get its potency
    const selectedMed = opioidMedications.find(med => med.name === newMed.name);
    
    const updatedMeds = [...currentMedications, { 
      ...newMed, 
      id: Date.now(),
      potency: selectedMed?.potency || "unknown" 
    }];
    onMedicationChange(updatedMeds);
    
    // Reset form
    setNewMed({
      name: "",
      dosage: "",
      frequency: "",
      duration: ""
    });
  };

  const handleRemoveMedication = (id: number) => {
    const updatedMeds = currentMedications.filter(med => med.id !== id);
    onMedicationChange(updatedMeds);
  };

  const handleAddCondition = (condition: string) => {
    if (!condition || medicalHistory.includes(condition)) return;
    onMedicalHistoryChange([...medicalHistory, condition]);
    setNewCondition("");
  };

  const handleRemoveCondition = (condition: string) => {
    onMedicalHistoryChange(medicalHistory.filter(c => c !== condition));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Current Opioid Medications</CardTitle>
          <CardDescription>Add all opioid medications the patient is currently taking</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label htmlFor="med-name" className="text-sm font-medium">Medication Name</label>
              <Select
                value={newMed.name}
                onValueChange={(value) => setNewMed({ ...newMed, name: value })}
              >
                <SelectTrigger id="med-name">
                  <SelectValue placeholder="Select opioid" />
                </SelectTrigger>
                <SelectContent>
                  {opioidMedications.map((med) => (
                    <SelectItem key={med.name} value={med.name}>
                      {med.name} <span className="text-xs text-gray-500">({med.potency} potency)</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label htmlFor="med-dosage" className="text-sm font-medium">Dosage</label>
              <Input
                id="med-dosage"
                value={newMed.dosage}
                onChange={(e) => setNewMed({ ...newMed, dosage: e.target.value })}
                placeholder="e.g. 10mg"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="med-frequency" className="text-sm font-medium">Frequency</label>
              <Select
                value={newMed.frequency}
                onValueChange={(value) => setNewMed({ ...newMed, frequency: value })}
              >
                <SelectTrigger id="med-frequency">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="once">Once daily</SelectItem>
                  <SelectItem value="twice">Twice daily</SelectItem>
                  <SelectItem value="three">Three times daily</SelectItem>
                  <SelectItem value="four">Four times daily</SelectItem>
                  <SelectItem value="asneeded">As needed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label htmlFor="med-duration" className="text-sm font-medium">Duration</label>
              <Input
                id="med-duration"
                value={newMed.duration}
                onChange={(e) => setNewMed({ ...newMed, duration: e.target.value })}
                placeholder="e.g. 7 days"
              />
            </div>
          </div>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleAddMedication}
            disabled={!newMed.name || !newMed.dosage || !newMed.frequency}
            className="flex items-center"
          >
            <Plus className="h-4 w-4 mr-1" /> Add Medication
          </Button>

          {currentMedications.length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Added Medications:</h4>
              <div className="bg-gray-50 p-3 rounded-md">
                {currentMedications.map((med) => (
                  <div key={med.id} className="flex items-center justify-between mb-2 p-2 bg-white rounded border">
                    <div>
                      <span className="font-medium">{med.name}</span>
                      {med.potency && (
                        <Badge 
                          className={`ml-2 ${
                            med.potency === 'high' || med.potency === 'very high' 
                              ? 'bg-red-500' 
                              : med.potency === 'moderate' 
                                ? 'bg-yellow-500' 
                                : 'bg-green-500'
                          }`}
                        >
                          {med.potency} potency
                        </Badge>
                      )}
                      <span className="text-sm text-gray-500 ml-2">
                        {med.dosage}, {med.frequency === "once" ? "Once daily" : 
                                      med.frequency === "twice" ? "Twice daily" : 
                                      med.frequency === "three" ? "Three times daily" : 
                                      med.frequency === "four" ? "Four times daily" : "As needed"}
                        {med.duration && `, ${med.duration}`}
                      </span>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleRemoveMedication(med.id)}
                      className="h-8 w-8 p-0"
                    >
                      <Trash className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Medical History</CardTitle>
          <CardDescription>Select or add any existing medical conditions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2 mb-4">
            {commonConditions.map((condition) => (
              <Badge 
                key={condition}
                variant={medicalHistory.includes(condition) ? "default" : "outline"}
                className={`cursor-pointer ${medicalHistory.includes(condition) ? 'bg-medical-500' : ''}`}
                onClick={() => {
                  if (medicalHistory.includes(condition)) {
                    handleRemoveCondition(condition);
                  } else {
                    handleAddCondition(condition);
                  }
                }}
              >
                {condition}
                {medicalHistory.includes(condition) && (
                  <X className="h-3 w-3 ml-1" />
                )}
              </Badge>
            ))}
          </div>
          
          <div className="flex space-x-2">
            <Input
              placeholder="Add other condition"
              value={newCondition}
              onChange={(e) => setNewCondition(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newCondition) {
                  handleAddCondition(newCondition);
                  e.preventDefault();
                }
              }}
            />
            <Button 
              onClick={() => handleAddCondition(newCondition)} 
              disabled={!newCondition}
            >
              Add
            </Button>
          </div>

          {medicalHistory.length > 0 && !commonConditions.some(c => medicalHistory.includes(c)) && (
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Custom Conditions:</h4>
              <div className="flex flex-wrap gap-2">
                {medicalHistory
                  .filter(condition => !commonConditions.includes(condition))
                  .map((condition) => (
                    <Badge 
                      key={condition} 
                      className="bg-medical-500"
                    >
                      {condition}
                      <X 
                        className="h-3 w-3 ml-1 cursor-pointer" 
                        onClick={() => handleRemoveCondition(condition)} 
                      />
                    </Badge>
                  ))
                }
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button 
            onClick={onAnalyze} 
            disabled={currentMedications.length === 0 || isLoading}
          >
            {isLoading ? "Analyzing..." : "Analyze Risk"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};
